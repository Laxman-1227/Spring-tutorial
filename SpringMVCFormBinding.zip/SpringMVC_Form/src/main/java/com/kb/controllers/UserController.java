package com.kb.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kb.model.Person;

@Controller
public class UserController {

	@RequestMapping(value="/displayPersonPage",method=RequestMethod.GET)
	public String displayUserPage(Model model){
		Person person = new Person();
		model.addAttribute("person", person);
		return "/personForm";
	}
	
	@RequestMapping(value="/personDetails",method=RequestMethod.POST)
	public String displayUserDetails(@ModelAttribute Person person,Model model){
		model.addAttribute("person", person);
		return "/personDetails";
	}
}
