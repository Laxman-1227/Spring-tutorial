package com.kb.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kb.exception.InvalidUserException;
import com.kb.model.User;

@Controller
public class LoginController {

	@RequestMapping(value="/displayLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model){
		User user = new User();
		model.addAttribute("user", user);
		return "/login";
	}
	
	@RequestMapping(value="/doLogin",method=RequestMethod.POST)
	public String doLogin(@ModelAttribute User user,Model model){
		
		String userName=user.getUserName();
		String password = user.getPassword();
		if("kb".equals(userName) && "1234".equals(password)){
			model.addAttribute("user", user);
			return "/home";
		}
		else{
			//Log the exception
			throw new InvalidUserException("INVALID_USER","User is not Valid for this site");
		}
		
	}
	
	@RequestMapping(value="/getGenericException",method=RequestMethod.GET)
	public String getGenericException(Model model) throws Exception{

		throw new Exception();
	}
	
	@ExceptionHandler(InvalidUserException.class)
	public String handleInvalidUserException(){

		return "userNotFound";
	}
	
}
