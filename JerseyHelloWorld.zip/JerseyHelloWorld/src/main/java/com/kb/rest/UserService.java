package com.kb.rest;

import java.util.List;

public class UserService {
	UserDao userDao = new UserDao();
	
	public User getUser(int userId) {
		
		
		return userDao.getUser(userId);
		
	}
	
	
	public User createUser(User user) {
		return userDao.createUser(user);
		
	}
	
	public User updateUser(User user) {
		return userDao.updateUser(user);
		
	}
	
	public User deleteUser(int userId) {
		return userDao.deleteUser(userId);
		
	}


	public List<User> getAllUser() {
		return userDao.getAllUsers();
	}


}
