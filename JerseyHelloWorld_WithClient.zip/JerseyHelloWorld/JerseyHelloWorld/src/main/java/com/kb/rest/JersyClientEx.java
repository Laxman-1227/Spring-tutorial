package com.kb.rest;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class JersyClientEx {

	public static void main(String[] args) {
		
		//http://localhost:8080/JerseyHelloWorld/rest/user/getAllUser
		
		try {
			Client client = Client.create();
//			WebResource webResource = client
//			   .resource("http://localhost:8080/JerseyHelloWorld/rest/user/getAllUser");
			WebResource webResource = client
					.resource("http://localhost:8080/JerseyHelloWorld/rest/user/getUser?userId=101");

			ClientResponse response = webResource.accept("application/json")
	                   .get(ClientResponse.class);

			if (response.getStatus() != 200) {
			   throw new RuntimeException("Request Processing Failed : HTTP error code : "
					   + response.getStatus());
			}

			String output = response.getEntity(String.class);

			System.out.println("Output received from Rest service ....");
			System.out.println(output);

		  } catch (Exception e) {

			e.printStackTrace();

		  }
		

	}

}
