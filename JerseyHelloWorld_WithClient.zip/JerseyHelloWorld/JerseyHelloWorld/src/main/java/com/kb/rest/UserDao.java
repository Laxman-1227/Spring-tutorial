package com.kb.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UserDao {
	
	static HashMap<Integer, User> hashMap = new HashMap<Integer, User>();
	
	UserDao(){
		
	User user = new User();
	user.setUserId(101);
	user.setUserName("Jhon");
	user.setAddress("Usa");
	
	User user1 = new User();
	user1.setUserId(102);
	user1.setUserName("alex");
	user1.setAddress("IND");
	
	hashMap.put(user.getUserId(), user);
	hashMap.put(user1.getUserId(), user1);
	}
	
	public User getUser(Integer userId) {
		
		return hashMap.get(userId);
	}
	
	public User createUser(User user) {
	 hashMap.put(user.getUserId(), user);
	 return hashMap.get(user.getUserId());
	}
	
	public User updateUser(User user) {
		
		if(hashMap.containsKey(user.getUserId())) {
			hashMap.get(user.getUserId()).setUserName(user.getUserName());
		}else {
			hashMap.put(user.getUserId(), user);
		}
		return hashMap.get(user.getUserId());
		
		
	}
	
	public User deleteUser(Integer userId) {
			return  hashMap.remove(userId);
		}

	public List<User> getAllUsers() {
		List<User> userList = new ArrayList<User>( hashMap.values());
		return userList;
	}
		

}
