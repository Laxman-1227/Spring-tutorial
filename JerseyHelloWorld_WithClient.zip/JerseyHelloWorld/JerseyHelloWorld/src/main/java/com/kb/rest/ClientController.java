package com.kb.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/client")
public class ClientController {

	@GET
	@Path("/getUserDetails")
	@Produces(MediaType.APPLICATION_JSON)
	public String getUser(@QueryParam("userId") int id) {
		String output = "";
		try {
			Client client = Client.create();
//			WebResource webResource = client
//			   .resource("http://localhost:8080/JerseyHelloWorld/rest/user/getAllUser");
			WebResource webResource = client
					.resource("http://localhost:8080/JerseyHelloWorld/rest/user/getUser?userId="+id+"");

			ClientResponse response = webResource.accept("application/json").get(ClientResponse.class);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Request Processing Failed : HTTP error code : " + response.getStatus());
			}

			output = response.getEntity(String.class);

			System.out.println("Output received from Rest service ....");
			System.out.println(output);

		} catch (Exception e) {

			e.printStackTrace();

		}
		return output;

	}
	
	@Path("/createUserDetails")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String getUser(User user) {
		String output = "";
		String input ="{\r\n"
				+ "    \"userName\": \"teja\",\r\n"
				+ "    \"userId\": 104,\r\n"
				+ "    \"address\": \"Usa\"\r\n"
				+ "}";
		try {
			Client client = Client.create();
//			WebResource webResource = client
//			   .resource("http://localhost:8080/JerseyHelloWorld/rest/user/getAllUser");
			WebResource webResource = client
					.resource("http://localhost:8080/JerseyHelloWorld/rest/user/createUser");

			ClientResponse response = webResource.type("application/json").post(ClientResponse.class,input );

			if (response.getStatus() != 200) {
				throw new RuntimeException("Request Processing Failed : HTTP error code : " + response.getStatus());
			}

			output = response.getEntity(String.class);

			System.out.println("Output received from Rest service ....");
			System.out.println(output);

		} catch (Exception e) {

			e.printStackTrace();

		}
		return output;

	}

}
