package com.kb.rest;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

@Path("/basePath")
public class QueryParamRestService {
//http://localhost:8080/JerseyHelloWorld/rest/queryParamPath?name=laxman&id=123
	@GET
	@Path("/queryParmPath")
	@Produces(MediaType.APPLICATION_JSON)
	public String getQueryParam(@DefaultValue("Teja") @QueryParam("name") String name, @DefaultValue("123") @QueryParam("id") int id ){
		
		return "Hello User "+name+" Id "+id;
		
	}
	
	
	@GET
	@Path("/context")
	@Produces(MediaType.APPLICATION_JSON)
	public String getContext( @Context UriInfo uriInfo){
		
		String name =uriInfo.getQueryParameters().getFirst("name");
		Integer id = Integer.parseInt(uriInfo.getQueryParameters().getFirst("id"));
		
		return "Hello User "+name+" Id "+id;
		
	}
	
	
	
	//http://localhost:8080/JerseyHelloWorld/rest/queryParamPath/Ram/1234
	@GET
	@Path("/PathParam/{name}/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getMessage( @PathParam("name") String name, @PathParam("id") int id ){
		
		return "Hello User "+name+" Id "+id;
		
	}
	
}
